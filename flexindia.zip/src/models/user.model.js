const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const { SUPER_ADMIN, ADMIN, AGENT, USER } = require('../constants/roles');

const userSchema = new mongoose.Schema({
    fullName: {
        type: String,
        required: function() { return this.role !== SUPER_ADMIN; } // SuperAdmin might not need a full name in a simple setup
    },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true,
        match: [/^[\w-]+(?:\.[\w-]+)*@(?:[\w-]+\.)+[a-zA-Z]{2,7}$/, 'Please fill a valid email address']
    },
    password: {
        type: String,
        required: true,
        minlength: 6 // Enforce minimum password length
    },
    phone: {
        type: String,
        required: function() { return this.role === AGENT; },
        unique: function() { return this.role === AGENT; }
    },
    status: {
        type: String,
        enum: ['Active', 'Inactive', 'Suspended'],
        default: 'Inactive' // Default for new users, SuperAdmin/Admin can set active
    },
    role: {
        type: String,
        enum: [SUPER_ADMIN, ADMIN, AGENT, USER],
        default: USER,
        required: true
    },
    country: {
        type: String,
        required: function() { return this.role === USER || this.role === AGENT; }
    },
    state: {
        type: String,
        required: function() { return this.role === USER || this.role === AGENT; }
    },
    city: {
        type: String,
        required: function() { return this.role === USER || this.role === AGENT; }
    },
    // Agent Specific Fields
    packageId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Package",
        required: function() { return this.role === AGENT; }
    },
    usersRegisteredCount: { // To track how many users an agent has registered
        type: Number,
        default: 0,
        required: function() { return this.role === AGENT; }
    },
    shopImage: { // URL to DigitalOcean Spaces
        type: String,
        default: "",
        required: function() { return this.role === AGENT; }
    },
    profileImage: { // URL to DigitalOcean Spaces
        type: String,
        default: "",
        required: function() { return this.role === AGENT; }
    },
    bankName: {
        type: String,
        required: function() { return this.role === AGENT; }
    },
    bankAccountNumber: {
        type: String,
        required: function() { return this.role === AGENT; }
    },
    ifscCode: {
        type: String,
        required: function() { return this.role === AGENT; }
    },
    // Who created this user (relevant for users created by Admin/Agent)
    createdBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User", // Refers to another User (Admin or Agent)
        required: function() { return this.role === USER && this.byAgentOrAdmin; } // Required if created by agent/admin
    },
    byAgentOrAdmin: { // To distinguish users created by self-registration vs. admin/agent
        type: Boolean,
        default: false
    },
    currentLoanEligibilityPackage: { // For users, which loan package they are eligible for
        type: mongoose.Schema.Types.ObjectId,
        ref: "Package",
        default: null
    },
    lastLoanAmount: { // To track the last loan amount for calculating next eligibility
        type: Number,
        default: 0
    }
}, { timestamps: true });

// Hash password before saving
userSchema.pre('save', async function (next) {
    if (!this.isModified('password')) {
        return next();
    }
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
});

// Method to compare password
userSchema.methods.matchPassword = async function (enteredPassword) {
    return await bcrypt.compare(enteredPassword, this.password);
};

module.exports = mongoose.model('User', userSchema);