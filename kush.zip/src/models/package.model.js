const mongoose = require("mongoose");

const packageSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true,
        unique: true,
        trim: true
    },
    description: {
        type: String,
        default: ""
    },
    type: { // 'loan' for user loan eligibility, 'agent' for agent user registration limit
        type: String,
        enum: ['loan', 'agent'],
        required: true
    },
    price: { // Relevant for agent packages, or if loan packages have a "fee"
        type: Number,
        default: 0
    },
    validityInDays: { // Relevant for agent packages (e.g., package valid for 30 days)
        type: Number,
        default: 0
    },
    maxUsers: { // Specific for 'agent' type packages
        type: Number,
        default: 0,
        required: function() { return this.type === 'agent'; }
    },
    minLoanAmount: { // Specific for 'loan' type packages
        type: Number,
        required: function() { return this.type === 'loan'; }
    },
    maxLoanAmount: { // Specific for 'loan' type packages
        type: Number,
        required: function() { return this.type === 'loan'; }
    },
    installmentMonths: { // Default installment months for this loan package
        type: Number,
        required: function() { return this.type === 'loan'; }
    },
    status: {
        type: String,
        enum: ['active', 'inactive'],
        default: "inactive"
    },
}, { timestamps: true });

module.exports = mongoose.model('Package', packageSchema);